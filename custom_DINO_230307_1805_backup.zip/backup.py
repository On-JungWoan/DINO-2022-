import argparse
import shutil
import os
from tqdm import tqdm

import time

def get_args_parser():
    parser = argparse.ArgumentParser('Set transformer detector', add_help=False)
    parser.add_argument('--project_dir', default='/home/unist/Desktop/OJW/')
    parser.add_argument('--file_name', default='custom_DINO') #arg this
    parser.add_argument('--ignore_dirs', nargs='+') #arg this

    return parser

def main(args):
    origin_path = os.path.join(args.project_dir, args.file_name)
    backup_path = os.path.join(args.project_dir, args.file_name + '_backup')

    if os.path.isdir(backup_path):
        shutil.rmtree(backup_path)
    os.mkdir(backup_path)

    files = (os.listdir(origin_path))

    print("****Progress in Copy****")
    for file in tqdm(files):
        if file not in args.ignore_dirs:
            try:
                shutil.copy(
                    os.path.join(origin_path, file),
                    os.path.join(backup_path, file)
                )
            except:
                shutil.copytree(
                    os.path.join(origin_path, file),
                    os.path.join(backup_path, file)
                )

    print("\n****Progress in Make Zip file****")
    shutil.make_archive(args.file_name + '_backup', 'zip', backup_path)
    shutil.rmtree(backup_path)
    print("\nsuccess!")

if __name__ == '__main__':
    parser = get_args_parser()
    args = parser.parse_args() 

    main(args)
    # if args.output_dir:
    #     Path(args.output_dir).mkdir(parents=True, exist_ok=True)
    # main(args)
