coco_path=$1
python main.py \
    --num_train $2 --num_val $3 $4\
	--output_dir logs/DINO/train_$2_$3_4scale_rs50_12epc \
    -c config/DINO/DINO_4scale.py --coco_path $coco_path \
	--options dn_scalar=100 embed_init_tgt=TRUE \
	dn_label_coef=1.0 dn_bbox_coef=1.0 use_ema=False \
	dn_box_noise_scale=1.0