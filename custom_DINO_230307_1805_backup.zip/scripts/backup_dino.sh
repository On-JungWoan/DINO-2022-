python backup.py \
    --ignore_dirs COCODIR ckpts logs